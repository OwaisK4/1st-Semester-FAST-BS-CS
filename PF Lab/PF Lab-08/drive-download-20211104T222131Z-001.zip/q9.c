#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
	int i,n=10,sum, array[n];
	float average;
	srand(time(0));
	for (i=0; i<n; i++){
		array[i] = rand();
	}
/*
	sum =
	average =
*/

	for (i=0; i<n; i++){
		printf("Array elements are = %d\n",array[i]);
	}
	return 0;
}