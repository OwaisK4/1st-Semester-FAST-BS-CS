#include <stdio.h>

struct courses{
	char course_name[50];
	float GPA;
};
struct address{
	char street[50], city[50], state[50];
	long int zip;	
};
struct student{
	float CGPA;
	struct courses course[2];
	struct address addr;
};

int main(){
	struct student s1, s2;
	int i;
	printf("Enter record of student 1:\n");
	printf("Enter CGPA: ");
	scanf("%f",&s1.CGPA);
	printf("Enter course name: ");
	scanf("%s",&s1.course[0].course_name);
	printf("Enter GPA: ");
	scanf("%f",&s1.course[0].GPA);
	printf("Enter course name: ");
	scanf("%s",&s1.course[1].course_name);
	printf("Enter GPA: ");
	scanf("%f",&s1.course[1].GPA);
	printf("Enter street address: ");
	scanf("%s",&s1.addr.street);
	printf("Enter City: ");
	scanf("%s",&s1.addr.city);
	printf("Enter state: ");
	scanf("%s",&s1.addr.state);
	printf("Enter Zip: ");
	scanf("%ld",&s1.addr.zip);
	
	fflush(stdin);
	printf("\nEnter record of student 2:\n");
	printf("Enter CGPA: ");
	scanf("%f",&s2.CGPA);
	printf("Enter course name: ");
	scanf("%s",&s2.course[0].course_name);
	printf("Enter GPA: ");
	scanf("%f",&s2.course[0].GPA);
	printf("Enter course name: ");
	scanf("%s",&s2.course[1].course_name);
	printf("Enter GPA: ");
	scanf("%f",&s2.course[1].GPA);
	printf("Enter street address: ");
	scanf("%s",&s2.addr.street);
	printf("Enter City: ");
	scanf("%s",&s2.addr.city);
	printf("Enter state: ");
	scanf("%s",&s2.addr.state);
	printf("Enter Zip: ");
	scanf("%ld",&s2.addr.zip);
	
//	printf("First course: %s\n", s1.course[0].course_name);
//	printf("Second course: %s\n", s1.course[1].course_name);
	
	for (i=0; i<2; i++){
		if (s1.course[0].GPA > s2.course[0].GPA)
			printf("\nStudent 1 has greater GPA in %s.\n",s1.course[i].course_name);
		else
			printf("\nStudent 2 has greater GPA in %s.\n",s1.course[i].course_name);
	}
	if (s1.CGPA > s2.CGPA)
		printf("Student 1 has greater CGPA: %.2f\n", s1.CGPA);
	else
		printf("Student 2 has greater CGPA: %.2f\n", s2.CGPA);
	return 0;
}
