#include <stdio.h>

struct phone{
	int area_code, exchange, number;
};

int main(){
	struct phone my_number = {212, 767, 8900};
	struct phone your_number;
	printf("Enter area code: ");
	scanf("%d", &your_number.area_code);
	printf("Enter exchange: ");
	scanf("%d", &your_number.exchange);
	printf("Enter number: ");
	scanf("%d", &your_number.number);
	printf("\nMy number is (%d) %d-%d", my_number.area_code, my_number.exchange, my_number.number);
	printf("\nYour number is (%d) %d-%d", your_number.area_code, your_number.exchange, your_number.number);
	return 0;
/*
The interchange might look like this:
Enter area code: 415
Enter exchange: 555
Enter number: 1212
Then display like below:
My number is (212) 767-8900
Your number is (415) 555-1212
*/
}
